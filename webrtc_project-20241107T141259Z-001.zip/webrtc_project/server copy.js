// webrtc_project/server.js
const fs = require('fs');
const https = require('https');
const express = require('express');
const socketIo = require('socket.io');
const { RTCPeerConnection, RTCSessionDescription } = require('wrtc');

// Sertifika dosyalarını yükleyin
const options = {
    key: fs.readFileSync('server.key'),
    cert: fs.readFileSync('server.crt')
};

const app = express();
const server = https.createServer(options, app);
const io = socketIo(server);

app.use(express.static('public'));

io.on('connection', (socket) => {
    console.log('Bir kullanıcı bağlandı');

    let peerConnection;
    
    socket.on('offer', async (offer) => {
        peerConnection = new RTCPeerConnection();
        
        await peerConnection.setRemoteDescription(new RTCSessionDescription(offer));
        
        const answer = await peerConnection.createAnswer();
        await peerConnection.setLocalDescription(answer);
        
        socket.emit('answer', peerConnection.localDescription);
        
        peerConnection.onicecandidate = ({ candidate }) => {
            if (candidate) {
                socket.emit('ice-candidate', candidate);
            }
        };
    });

    socket.on('ice-candidate', (candidate) => {
        peerConnection.addIceCandidate(candidate);
    });

    socket.on('disconnect', () => {
        console.log('Bir kullanıcı ayrıldı');
        if (peerConnection) {
            peerConnection.close();
            peerConnection = null;
        }
    });
});

server.listen(3000, () => {
    console.log('Sunucu 3000 portunda HTTPS ile çalışıyor');
});
