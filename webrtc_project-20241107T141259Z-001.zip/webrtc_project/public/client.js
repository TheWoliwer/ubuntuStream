const socket = io();

// Sunucudan gelen 'new_client' mesajını dinle
socket.on('new_client', (data) => {
    const videoContainer = document.getElementById('videoContainer');

    // Yeni video elementi oluştur ve IP adresini ID olarak ata
    const videoElement = document.createElement('video');
    videoElement.id = `video_${data.ip}`;
    videoElement.autoplay = true;
    videoElement.controls = true; // İsteğe bağlı, durdurma ve başlatma butonları ekler
    videoContainer.appendChild(videoElement);

    // Yeni bir MediaStream oluştur ve video kaynağını bu stream'e ata
    const remoteStream = new MediaStream();
    videoElement.srcObject = remoteStream;

    // 'track' olayını dinleyerek gelen video verisini remoteStream'e ekleyin
    socket.on('track', ({ track }) => {
        remoteStream.addTrack(track);
    });
});
