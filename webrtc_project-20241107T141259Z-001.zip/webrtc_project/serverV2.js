const fs = require('fs');
const https = require('https');
const express = require('express');
const socketIo = require('socket.io');
const { RTCPeerConnection, RTCSessionDescription } = require('wrtc');

(async () => {
    const chalk = await import('chalk'); // chalk'ı dinamik olarak içe aktarıyoruz

    // Sertifika dosyalarını yükleyin
    const options = {
        key: fs.readFileSync('server.key'),
        cert: fs.readFileSync('server.crt')
    };

    const app = express();
    const server = https.createServer(options, app);
    const io = socketIo(server);

    app.use(express.static('public'));

    // Tüm istemciler için peerConnections nesnesi
    const peerConnections = {};

    io.on('connection', (socket) => {
        const ipAddress = socket.handshake.address; // Kullanıcı IP'sini al

        // İstemciden gelen GroupID ve ID bilgilerini alın
        socket.on("client_info", (data) => {
            const groupID = data.groupID;
            const clientID = data.clientID;
            console.log(chalk.default.green(`Yeni bağlantı: groupID=${groupID} ID=${clientID} IP=${ipAddress}`));
        });

        // Yayıncı olarak bağlanan istemciyi ayarla
        socket.on('offer', async (offer) => {
            const peerConnection = new RTCPeerConnection();
            peerConnections[socket.id] = peerConnection;

            await peerConnection.setRemoteDescription(new RTCSessionDescription(offer));
            
            const answer = await peerConnection.createAnswer();
            await peerConnection.setLocalDescription(answer);

            socket.emit('answer', peerConnection.localDescription);

            peerConnection.onicecandidate = ({ candidate }) => {
                if (candidate) {
                    socket.emit('ice-candidate', candidate);
                }
            };
        });

        // İzleyici olarak bağlanan istemciyi ayarla
        socket.on('watcher', () => {
            const peerConnection = new RTCPeerConnection();
            peerConnections[socket.id] = peerConnection;

            // Yayıncının bağlantısını izleyiciye yönlendirin
            peerConnection.onicecandidate = ({ candidate }) => {
                if (candidate) {
                    socket.emit('ice-candidate', candidate);
                }
            };

            peerConnection.ontrack = (event) => {
                socket.emit('track', { track: event.track });
            };

            console.log(chalk.default.yellow(`Bir izleyici bağlandı: IP=${ipAddress}`));
        });

        socket.on('ice-candidate', (candidate) => {
            const peerConnection = peerConnections[socket.id];
            if (peerConnection) {
                peerConnection.addIceCandidate(candidate);
            }
        });

        // Bağlantı kesilince temizleme
        socket.on('disconnect', () => {
            const peerConnection = peerConnections[socket.id];
            if (peerConnection) {
                peerConnection.close();
                delete peerConnections[socket.id];
            }
            console.log(chalk.default.red(`Bağlantı kesildi: IP=${ipAddress}`));
        });
    });

    server.listen(3000, () => {
        console.log(chalk.default.blue('Sunucu 3000 portunda HTTPS ile çalışıyor'));
    });
})();
